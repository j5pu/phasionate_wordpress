<?php

class WPBakeryShortCode_VC_Column_Inner extends WPBakeryShortCode_VC_Column {
}